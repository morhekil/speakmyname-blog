--- src/mod_status.c.orig	2009-04-28 00:20:40.000000000 +0300
+++ src/mod_status.c	2010-02-22 20:59:19.000000000 +0200
@@ -723,18 +723,18 @@
 	}
 	mod_status_row_append(b, "Supported fd-Event-Handlers", tmp_buf->ptr);
 
-	mod_status_row_append(b, "Network-Backend", network_get_backend_info_by_type(srv->network_backend)->name);
-	buffer_reset(tmp_buf);
-	for (backend = network_get_backends(); backend->name; backend++) {
-		if (backend->write_handler) {
-			buffer_append_string_len(tmp_buf, CONST_STR_LEN("+ "));
-		} else {
-			buffer_append_string_len(tmp_buf, CONST_STR_LEN("- "));
-		}
-
-		buffer_append_string(tmp_buf, backend->name);
-		buffer_append_string_len(tmp_buf, CONST_STR_LEN("<br />"));
-	}
+  // mod_status_row_append(b, "Network-Backend", network_get_backend_info_by_type(srv->network_backend)->name);
+  // buffer_reset(tmp_buf);
+  // for (backend = network_get_backends(); backend->name; backend++) {
+  //  if (backend->write_handler) {
+  //    buffer_append_string_len(tmp_buf, CONST_STR_LEN("+ "));
+  //  } else {
+  //    buffer_append_string_len(tmp_buf, CONST_STR_LEN("- "));
+  //  }
+  // 
+  //  buffer_append_string(tmp_buf, backend->name);
+  //  buffer_append_string_len(tmp_buf, CONST_STR_LEN("<br />"));
+  // }
 #ifdef USE_MMAP
 	buffer_append_string_len(tmp_buf, CONST_STR_LEN("+ (mmap)<br />"));
 #else
